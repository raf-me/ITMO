using CarRental.Domain.Entities;
using CarRental.Domain.Enums;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CarRental.Infrastructure.Persistence.Configurations;

public class RoleConfiguration : IEntityTypeConfiguration<Role>
{
    public void Configure(EntityTypeBuilder<Role> builder)
    {
        builder.HasKey(r => r.Id);
        builder.Property(r => r.Name).HasConversion<string>().HasMaxLength(32).IsRequired();
        builder.HasIndex(r => r.Name).IsUnique();
        builder.Navigation(r => r.Users).UsePropertyAccessMode(PropertyAccessMode.Field);
        builder.HasData(
            new Role(Guid.Parse("11111111-1111-1111-1111-111111111111"), UserRole.Client),
            new Role(Guid.Parse("22222222-2222-2222-2222-222222222222"), UserRole.Manager),
            new Role(Guid.Parse("33333333-3333-3333-3333-333333333333"), UserRole.Admin));
    }
}

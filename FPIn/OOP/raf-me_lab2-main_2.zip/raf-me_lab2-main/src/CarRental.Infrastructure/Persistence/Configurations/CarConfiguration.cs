using CarRental.Domain.Entities;
using CarRental.Domain.ValueObjects;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CarRental.Infrastructure.Persistence.Configurations;

public class CarConfiguration : IEntityTypeConfiguration<Car>
{
    public void Configure(EntityTypeBuilder<Car> builder)
    {
        builder.HasKey(c => c.Id);
        builder.Property(c => c.Vin)
            .HasConversion(v => v.Value, v => Vin.Create(v))
            .HasMaxLength(17)
            .IsRequired();
        builder.HasIndex(c => c.Vin).IsUnique();
        builder.Property(c => c.Make).HasMaxLength(100).IsRequired();
        builder.Property(c => c.Model).HasMaxLength(100).IsRequired();
        builder.Property(c => c.DailyRate).HasPrecision(18, 2).IsRequired();
        builder.Property(c => c.Category).HasConversion<string>().HasMaxLength(32).IsRequired();
        builder.Property(c => c.Status).HasConversion<string>().HasMaxLength(32).IsRequired();
        builder.HasMany(c => c.RentalRequests)
            .WithOne(r => r.Car)
            .HasForeignKey(r => r.CarId)
            .OnDelete(DeleteBehavior.Restrict);
        builder.Navigation(c => c.RentalRequests).UsePropertyAccessMode(PropertyAccessMode.Field);
    }
}

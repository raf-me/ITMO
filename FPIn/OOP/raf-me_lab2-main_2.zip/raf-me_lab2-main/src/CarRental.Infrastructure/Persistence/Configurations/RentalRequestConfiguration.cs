using CarRental.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CarRental.Infrastructure.Persistence.Configurations;

public class RentalRequestConfiguration : IEntityTypeConfiguration<RentalRequest>
{
    public void Configure(EntityTypeBuilder<RentalRequest> builder)
    {
        builder.HasKey(r => r.Id);
        builder.Property(r => r.Status).HasConversion<string>().HasMaxLength(32).IsRequired();
        builder.Property(r => r.ManagerComment).HasMaxLength(500);
        builder.Property(r => r.CreatedAt).IsRequired();
        builder.HasOne(r => r.Contract)
            .WithOne(c => c.RentalRequest)
            .HasForeignKey<RentalContract>(c => c.RentalRequestId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}

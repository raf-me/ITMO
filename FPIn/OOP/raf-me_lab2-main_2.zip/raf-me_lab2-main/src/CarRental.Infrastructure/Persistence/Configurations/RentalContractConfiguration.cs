using CarRental.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CarRental.Infrastructure.Persistence.Configurations;

public class RentalContractConfiguration : IEntityTypeConfiguration<RentalContract>
{
    public void Configure(EntityTypeBuilder<RentalContract> builder)
    {
        builder.HasKey(c => c.Id);
        builder.HasIndex(c => c.RentalRequestId).IsUnique();
        builder.Property(c => c.BasePrice).HasPrecision(18, 2).IsRequired();
        builder.Property(c => c.LateFee).HasPrecision(18, 2).IsRequired();
        builder.Property(c => c.DamageFee).HasPrecision(18, 2).IsRequired();
        builder.Property(c => c.TotalPrice).HasPrecision(18, 2).IsRequired();
        builder.Property(c => c.CreatedAt).IsRequired();
    }
}

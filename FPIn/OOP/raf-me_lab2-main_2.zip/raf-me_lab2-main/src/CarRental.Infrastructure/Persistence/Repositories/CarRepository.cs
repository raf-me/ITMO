using CarRental.Application.Abstractions.Repositories;
using CarRental.Domain.Entities;
using CarRental.Domain.Enums;
using CarRental.Domain.ValueObjects;
using CarRental.Infrastructure.Persistence.Specifications;
using Microsoft.EntityFrameworkCore;

namespace CarRental.Infrastructure.Persistence.Repositories;

public class CarRepository : ICarRepository
{
    private readonly ApplicationDbContext _context;

    public CarRepository(ApplicationDbContext context) => _context = context;

    public Task<Car?> GetByIdAsync(Guid id, CancellationToken ct = default) =>
        _context.Cars.FirstOrDefaultAsync(c => c.Id == id, ct);

    public Task<Car?> GetByVinAsync(string vin, CancellationToken ct = default)
    {
        var value = Vin.Create(vin);
        return _context.Cars.FirstOrDefaultAsync(c => c.Vin == value, ct);
    }

    public async Task<(IReadOnlyList<Car> Items, int TotalCount)> GetPagedAsync(
        CarStatus? status, CarCategory? category,
        decimal? minPricePerDay, decimal? maxPricePerDay,
        int page, int pageSize, CancellationToken ct = default)
    {
        var specification = new CarFilterSpecification(status, category, minPricePerDay, maxPricePerDay);
        IQueryable<Car> query = specification.Apply(_context.Cars.AsNoTracking());

        int total = await query.CountAsync(ct);
        var items = await query.OrderBy(c => c.Make).ThenBy(c => c.Model)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(ct);
        return (items, total);
    }

    public Task<bool> ExistsByVinAsync(string vin, CancellationToken ct = default)
    {
        var value = Vin.Create(vin);
        return _context.Cars.AnyAsync(c => c.Vin == value, ct);
    }

    public void Add(Car car) => _context.Cars.Add(car);

    public void Update(Car car) => _context.Cars.Update(car);
}

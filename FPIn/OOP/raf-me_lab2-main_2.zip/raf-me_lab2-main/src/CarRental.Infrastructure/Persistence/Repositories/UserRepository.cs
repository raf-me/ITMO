using CarRental.Application.Abstractions.Repositories;
using CarRental.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace CarRental.Infrastructure.Persistence.Repositories;

public class UserRepository : IUserRepository
{
    private readonly ApplicationDbContext _context;

    public UserRepository(ApplicationDbContext context) => _context = context;

    public Task<User?> GetByIdWithRolesAsync(Guid id, CancellationToken ct = default) =>
        _context.Users.Include(u => u.Roles).FirstOrDefaultAsync(u => u.Id == id, ct);

    public Task<User?> GetByUsernameWithRolesAsync(string username, CancellationToken ct = default) =>
        _context.Users.Include(u => u.Roles).FirstOrDefaultAsync(u => u.Username == username, ct);

    public async Task<(IReadOnlyList<User> Items, int TotalCount)> GetPagedAsync(
        int page, int pageSize, CancellationToken ct = default)
    {
        IQueryable<User> query = _context.Users.Include(u => u.Roles).AsNoTracking();
        int total = await query.CountAsync(ct);
        var items = await query.OrderBy(u => u.Username)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(ct);
        return (items, total);
    }

    public Task<bool> ExistsByUsernameAsync(string username, CancellationToken ct = default) =>
        _context.Users.AnyAsync(u => u.Username == username, ct);

    public void Add(User user) => _context.Users.Add(user);

    public void Update(User user) => _context.Users.Update(user);
}

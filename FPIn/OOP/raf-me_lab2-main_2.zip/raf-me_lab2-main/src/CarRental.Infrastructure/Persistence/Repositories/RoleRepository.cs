using CarRental.Application.Abstractions.Repositories;
using CarRental.Domain.Entities;
using CarRental.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace CarRental.Infrastructure.Persistence.Repositories;

public class RoleRepository : IRoleRepository
{
    private readonly ApplicationDbContext _context;

    public RoleRepository(ApplicationDbContext context) => _context = context;

    public Task<Role?> GetByRoleTypeAsync(UserRole role, CancellationToken ct = default) =>
        _context.Roles.FirstOrDefaultAsync(r => r.Name == role, ct);

    public async Task<IReadOnlyList<Role>> GetAllAsync(CancellationToken ct = default) =>
        await _context.Roles.AsNoTracking().OrderBy(r => r.Name).ToListAsync(ct);
}

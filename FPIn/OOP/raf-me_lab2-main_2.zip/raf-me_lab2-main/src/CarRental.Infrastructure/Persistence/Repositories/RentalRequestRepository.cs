using CarRental.Application.Abstractions.Repositories;
using CarRental.Domain.Entities;
using CarRental.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace CarRental.Infrastructure.Persistence.Repositories;

public class RentalRequestRepository : IRentalRequestRepository
{
    private readonly ApplicationDbContext _context;

    public RentalRequestRepository(ApplicationDbContext context) => _context = context;

    public Task<RentalRequest?> GetByIdWithDetailsAsync(Guid id, CancellationToken ct = default) =>
        _context.RentalRequests
            .Include(r => r.User)
            .Include(r => r.Car)
            .Include(r => r.Contract)
            .FirstOrDefaultAsync(r => r.Id == id, ct);

    public async Task<(IReadOnlyList<RentalRequest> Items, int TotalCount)> GetPagedAsync(
        Guid? userId, RentalRequestStatus? status,
        int page, int pageSize, CancellationToken ct = default)
    {
        IQueryable<RentalRequest> query = _context.RentalRequests
            .Include(r => r.User)
            .Include(r => r.Car)
            .AsNoTracking();
        if (userId is not null) query = query.Where(r => r.UserId == userId);
        if (status is not null) query = query.Where(r => r.Status == status);

        int total = await query.CountAsync(ct);
        var items = await query.OrderByDescending(r => r.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(ct);
        return (items, total);
    }

    public Task<bool> HasOverlappingRequestsAsync(
        Guid carId, DateOnly startDate, DateOnly endDate,
        Guid? excludeRequestId = null, CancellationToken ct = default)
    {
        return _context.RentalRequests.AnyAsync(r =>
            r.CarId == carId &&
            r.Status != RentalRequestStatus.Rejected &&
            r.Status != RentalRequestStatus.Completed &&
            (excludeRequestId == null || r.Id != excludeRequestId) &&
            r.StartDate < endDate &&
            startDate < r.EndDate,
            ct);
    }

    public void Add(RentalRequest request) => _context.RentalRequests.Add(request);

    public void Update(RentalRequest request) => _context.RentalRequests.Update(request);
}

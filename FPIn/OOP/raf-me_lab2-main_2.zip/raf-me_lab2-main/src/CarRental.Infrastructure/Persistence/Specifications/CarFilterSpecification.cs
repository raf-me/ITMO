using CarRental.Domain.Entities;
using CarRental.Domain.Enums;

namespace CarRental.Infrastructure.Persistence.Specifications;

public sealed class CarFilterSpecification
{
    public CarFilterSpecification(
        CarStatus? status,
        CarCategory? category,
        decimal? minPricePerDay,
        decimal? maxPricePerDay)
    {
        Status = status;
        Category = category;
        MinPricePerDay = minPricePerDay;
        MaxPricePerDay = maxPricePerDay;
    }

    private CarStatus? Status { get; }

    private CarCategory? Category { get; }

    private decimal? MinPricePerDay { get; }

    private decimal? MaxPricePerDay { get; }

    public IQueryable<Car> Apply(IQueryable<Car> query)
    {
        if (Status is not null) query = query.Where(c => c.Status == Status.Value);
        if (Category is not null) query = query.Where(c => c.Category == Category.Value);
        if (MinPricePerDay is not null) query = query.Where(c => c.DailyRate >= MinPricePerDay.Value);
        if (MaxPricePerDay is not null) query = query.Where(c => c.DailyRate <= MaxPricePerDay.Value);

        return query;
    }
}

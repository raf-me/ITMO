using CarRental.Application.DTOs;
using CarRental.Domain.Entities;

namespace CarRental.Application.Mappings;

public static class EntityMappingExtensions
{
    public static CarDto ToDto(this Car car) => new(
        car.Id,
        car.Vin.Value,
        car.Make,
        car.Model,
        car.Year,
        car.Category,
        car.Status,
        car.DailyRate,
        car.Mileage);

    public static UserDto ToDto(this User user) => new(
        user.Id,
        user.Username,
        user.FirstName,
        user.LastName,
        user.Email,
        user.DateOfBirth,
        user.LicenseDate,
        user.Roles.Select(r => r.Name.ToString()).ToList());

    public static RentalRequestDto ToDto(this RentalRequest r) => new(
        r.Id,
        r.UserId,
        r.User?.Username ?? string.Empty,
        r.CarId,
        r.Car?.Vin.Value ?? string.Empty,
        r.Car?.Make ?? string.Empty,
        r.Car?.Model ?? string.Empty,
        r.StartDate,
        r.EndDate,
        r.Status,
        r.ManagerComment,
        r.CreatedAt);

    public static RentalContractDto ToDto(this RentalContract c) => new(
        c.Id,
        c.RentalRequestId,
        c.BasePrice,
        c.LateFee,
        c.DamageFee,
        c.TotalPrice,
        c.ActualReturnDate,
        c.CreatedAt);
}

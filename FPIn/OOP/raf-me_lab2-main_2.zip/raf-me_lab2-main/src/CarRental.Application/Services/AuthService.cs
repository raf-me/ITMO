using CarRental.Application.Abstractions.Repositories;
using CarRental.Application.Abstractions.Services;
using CarRental.Application.Abstractions.UseCases;
using CarRental.Application.DTOs;
using CarRental.Application.Mappings;
using CarRental.Domain.Enums;
using CarRental.Domain.Exceptions;
using CarRental.Domain.Factories;

namespace CarRental.Application.Services;

public class AuthService : IAuthService
{
    private readonly IUserRepository _userRepo;

    private readonly IRoleRepository _roleRepo;

    private readonly IPasswordHasher _passwordHasher;

    private readonly IJwtTokenGenerator _jwtGenerator;

    private readonly IUnitOfWork _uow;

    private readonly IUserFactory _userFactory;

    public AuthService(
        IUserRepository userRepo,
        IRoleRepository roleRepo,
        IPasswordHasher passwordHasher,
        IJwtTokenGenerator jwtGenerator,
        IUnitOfWork uow,
        IUserFactory userFactory)
    {
        _userRepo = userRepo;
        _roleRepo = roleRepo;
        _passwordHasher = passwordHasher;
        _jwtGenerator = jwtGenerator;
        _uow = uow;
        _userFactory = userFactory;
    }

    public async Task<AuthResponseDto> LoginAsync(LoginDto dto, CancellationToken ct = default)
    {
        var user = await _userRepo.GetByUsernameWithRolesAsync(dto.Username, ct);
        if (user is null || !_passwordHasher.Verify(dto.Password, user.PasswordHash))
            throw new UnauthorizedAccessException("Неверный логин или пароль.");

        return new AuthResponseDto(_jwtGenerator.GenerateToken(user), "Bearer", 3600, user.ToDto());
    }

    public async Task<AuthResponseDto> RegisterAsync(RegisterDto dto, CancellationToken ct = default)
    {
        if (await _userRepo.ExistsByUsernameAsync(dto.Username, ct))
            throw new DuplicateUsernameException(dto.Username);

        var user = _userFactory.Create(
            dto.Username,
            _passwordHasher.Hash(dto.Password),
            dto.FirstName,
            dto.LastName,
            dto.DateOfBirth,
            dto.LicenseDate,
            dto.Email);
        var clientRole = await _roleRepo.GetByRoleTypeAsync(UserRole.Client, ct)
            ?? throw new InvalidOperationException("Роль Client не найдена.");
        user.AddRole(clientRole);
        _userRepo.Add(user);
        await _uow.SaveChangesAsync(ct);

        return new AuthResponseDto(_jwtGenerator.GenerateToken(user), "Bearer", 3600, user.ToDto());
    }
}

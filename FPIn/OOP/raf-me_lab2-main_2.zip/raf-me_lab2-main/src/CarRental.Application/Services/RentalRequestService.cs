using CarRental.Application.Abstractions.Repositories;
using CarRental.Application.Abstractions.UseCases;
using CarRental.Application.Common;
using CarRental.Application.DTOs;
using CarRental.Application.Mappings;
using CarRental.Domain.Enums;
using CarRental.Domain.Exceptions;
using CarRental.Domain.Factories;

namespace CarRental.Application.Services;

public class RentalRequestService : IRentalRequestService
{
    private readonly IRentalRequestRepository _requestRepo;

    private readonly IRentalContractRepository _contractRepo;

    private readonly ICarRepository _carRepo;

    private readonly IUserRepository _userRepo;

    private readonly IUnitOfWork _uow;

    private readonly IRentalEligibilityService _eligibility;

    private readonly IRentalPricingService _pricing;

    private readonly IRentalContractFactory _contractFactory;

    public RentalRequestService(
        IRentalRequestRepository requestRepo,
        IRentalContractRepository contractRepo,
        ICarRepository carRepo,
        IUserRepository userRepo,
        IUnitOfWork uow,
        IRentalEligibilityService eligibility,
        IRentalPricingService pricing,
        IRentalContractFactory contractFactory)
    {
        _requestRepo = requestRepo;
        _contractRepo = contractRepo;
        _carRepo = carRepo;
        _userRepo = userRepo;
        _uow = uow;
        _eligibility = eligibility;
        _pricing = pricing;
        _contractFactory = contractFactory;
    }

    public async Task<RentalRequestDto> CreateRequestAsync(
        CreateRentalRequestDto dto, Guid clientId, CancellationToken ct = default)
    {
        var car = await _carRepo.GetByIdAsync(dto.CarId, ct)
            ?? throw new KeyNotFoundException("Автомобиль не найден.");
        var user = await _userRepo.GetByIdWithRolesAsync(clientId, ct)
            ?? throw new KeyNotFoundException("Пользователь не найден.");

        if (car.Status != CarStatus.Available)
            throw new CarNotAvailableException(car.Id);
        _eligibility.EnsureEligible(user, car.Category);

        if (await _requestRepo.HasOverlappingRequestsAsync(car.Id, dto.StartDate, dto.EndDate, null, ct))
            throw new CarNotAvailableException(car.Id);

        var request = new RentalRequest(Guid.NewGuid(), clientId, car.Id, dto.StartDate, dto.EndDate);
        _requestRepo.Add(request);
        await _uow.SaveChangesAsync(ct);

        request = await _requestRepo.GetByIdWithDetailsAsync(request.Id, ct) ?? request;
        return request.ToDto();
    }

    public async Task<PagedResult<RentalRequestDto>> GetRequestsAsync(
        Guid currentUserId, bool isManager,
        RentalRequestStatus? status, int page, int pageSize,
        CancellationToken ct = default)
    {
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 1, 100);
        Guid? userId = isManager ? null : currentUserId;
        var (items, totalCount) = await _requestRepo.GetPagedAsync(userId, status, page, pageSize, ct);
        return new PagedResult<RentalRequestDto>(items.Select(r => r.ToDto()).ToList(), totalCount, page, pageSize);
    }

    public async Task<RentalContractDto> ApproveRequestAsync(Guid requestId, CancellationToken ct = default)
    {
        var request = await _requestRepo.GetByIdWithDetailsAsync(requestId, ct)
            ?? throw new KeyNotFoundException("Заявка не найдена.");
        if (request.Car.Status != CarStatus.Available)
            throw new CarNotAvailableException(request.CarId);
        if (await _requestRepo.HasOverlappingRequestsAsync(request.CarId, request.StartDate, request.EndDate, request.Id, ct))
            throw new CarNotAvailableException(request.CarId);

        request.Approve();
        request.Car.Rent();
        decimal basePrice = _pricing.CalculateBasePrice(request.Car, request.StartDate, request.EndDate);
        var contract = _contractFactory.CreateFor(request, basePrice);
        _requestRepo.Update(request);
        _contractRepo.Add(contract);
        await _uow.SaveChangesAsync(ct);
        return contract.ToDto();
    }

    public async Task RejectRequestAsync(Guid requestId, string reason, CancellationToken ct = default)
    {
        var request = await _requestRepo.GetByIdWithDetailsAsync(requestId, ct)
            ?? throw new KeyNotFoundException("Заявка не найдена.");
        request.Reject(reason);
        _requestRepo.Update(request);
        await _uow.SaveChangesAsync(ct);
    }

    public async Task<RentalContractDto> CompleteRentalAsync(
        Guid requestId, CompleteRentalDto dto, CancellationToken ct = default)
    {
        var request = await _requestRepo.GetByIdWithDetailsAsync(requestId, ct)
            ?? throw new KeyNotFoundException("Заявка не найдена.");
        var contract = await _contractRepo.GetByRentalRequestIdAsync(requestId, ct)
            ?? throw new KeyNotFoundException("Договор не найден.");

        request.Complete();
        if (request.Car.Status == CarStatus.Rented)
            request.Car.Complete();
        decimal lateFee = _pricing.CalculateLateFee(request.Car, request.EndDate, dto.ActualReturnDate);
        contract.Complete(dto.ActualReturnDate, lateFee, dto.DamageFee);
        _requestRepo.Update(request);
        _contractRepo.Update(contract);
        await _uow.SaveChangesAsync(ct);
        return contract.ToDto();
    }
}

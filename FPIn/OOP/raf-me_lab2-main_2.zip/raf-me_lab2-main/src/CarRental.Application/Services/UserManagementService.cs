using CarRental.Application.Abstractions.Repositories;
using CarRental.Application.Abstractions.Services;
using CarRental.Application.Abstractions.UseCases;
using CarRental.Application.Common;
using CarRental.Application.DTOs;
using CarRental.Application.Mappings;
using CarRental.Domain.Enums;
using CarRental.Domain.Exceptions;
using CarRental.Domain.Factories;

namespace CarRental.Application.Services;

public class UserManagementService : IUserManagementService
{
    private readonly IUserRepository _userRepo;

    private readonly IRoleRepository _roleRepo;

    private readonly IPasswordHasher _passwordHasher;

    private readonly IUnitOfWork _uow;

    private readonly IUserFactory _userFactory;

    public UserManagementService(
        IUserRepository userRepo,
        IRoleRepository roleRepo,
        IPasswordHasher passwordHasher,
        IUnitOfWork uow,
        IUserFactory userFactory)
    {
        _userRepo = userRepo;
        _roleRepo = roleRepo;
        _passwordHasher = passwordHasher;
        _uow = uow;
        _userFactory = userFactory;
    }

    public async Task<PagedResult<UserDto>> GetUsersAsync(int page, int pageSize, CancellationToken ct = default)
    {
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 1, 100);
        var (items, totalCount) = await _userRepo.GetPagedAsync(page, pageSize, ct);
        return new PagedResult<UserDto>(items.Select(u => u.ToDto()).ToList(), totalCount, page, pageSize);
    }

    public async Task<UserDto> CreateUserAsync(CreateUserDto dto, CancellationToken ct = default)
    {
        if (await _userRepo.ExistsByUsernameAsync(dto.Username, ct))
            throw new DuplicateUsernameException(dto.Username);

        var user = _userFactory.Create(
            dto.Username,
            _passwordHasher.Hash(dto.Password),
            dto.FirstName,
            dto.LastName,
            dto.DateOfBirth,
            dto.LicenseDate,
            dto.Email);
        var clientRole = await _roleRepo.GetByRoleTypeAsync(UserRole.Client, ct)
            ?? throw new InvalidOperationException("Роль Client не найдена.");
        user.AddRole(clientRole);
        _userRepo.Add(user);
        await _uow.SaveChangesAsync(ct);
        return user.ToDto();
    }

    public async Task AssignRoleAsync(Guid userId, AssignRoleDto dto, CancellationToken ct = default)
    {
        var user = await _userRepo.GetByIdWithRolesAsync(userId, ct)
            ?? throw new KeyNotFoundException("Пользователь не найден.");
        var role = await _roleRepo.GetByRoleTypeAsync(dto.Role, ct)
            ?? throw new ArgumentException("Роль не найдена.");

        user.AddRole(role);
        _userRepo.Update(user);
        await _uow.SaveChangesAsync(ct);
    }
}

using CarRental.Application.Abstractions.UseCases;
using CarRental.Domain.Entities;
using CarRental.Domain.Enums;
using CarRental.Domain.Exceptions;
using CarRental.Domain.Policies;

namespace CarRental.Application.Services;

public class RentalEligibilityService : IRentalEligibilityService
{
    private readonly IDriverEligibilityPolicy _eligibilityPolicy;

    public RentalEligibilityService()
        : this(new DefaultDriverEligibilityPolicy())
    {
    }

    public RentalEligibilityService(IDriverEligibilityPolicy eligibilityPolicy)
    {
        _eligibilityPolicy = eligibilityPolicy;
    }

    public void EnsureEligible(User user, CarCategory category)
    {
        ArgumentNullException.ThrowIfNull(user);

        DriverEligibilityRequirement requirement = _eligibilityPolicy.GetRequirementFor(category);

        if (user.AgeInYears < requirement.MinimumAgeYears)
        {
            throw new UserNotEligibleException(
                user.Id,
                $"для категории {category} требуется возраст не менее {requirement.MinimumAgeYears} лет");
        }

        if (user.DrivingExperienceYears < requirement.MinimumDrivingExperienceYears)
        {
            throw new InsufficientDriverExperienceException(
                category,
                requirement.MinimumDrivingExperienceYears,
                user.DrivingExperienceYears);
        }
    }
}

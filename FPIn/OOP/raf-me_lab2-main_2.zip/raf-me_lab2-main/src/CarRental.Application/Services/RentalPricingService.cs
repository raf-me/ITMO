using CarRental.Application.Abstractions.UseCases;
using CarRental.Domain.Entities;
using CarRental.Domain.Services;
using CarRental.Domain.ValueObjects;

namespace CarRental.Application.Services;

public class RentalPricingService : IRentalPricingService
{
    private readonly IRentalPriceCalculator _priceCalculator;

    public RentalPricingService()
        : this(new RentalPriceCalculator())
    {
    }

    public RentalPricingService(IRentalPriceCalculator priceCalculator)
    {
        _priceCalculator = priceCalculator;
    }

    public decimal CalculateBasePrice(Car car, DateOnly startDate, DateOnly endDate)
    {
        DateRange range = DateRange.Create(startDate, endDate);
        return _priceCalculator.CalculateBasePrice(car, range);
    }

    public decimal CalculateLateFee(Car car, DateOnly plannedReturnDate, DateOnly actualReturnDate)
    {
        return _priceCalculator.CalculateLateFee(car, plannedReturnDate, actualReturnDate);
    }

    public decimal CalculateTotalPrice(decimal basePrice, decimal lateFee, decimal damageFee)
    {
        return _priceCalculator.CalculateTotal(basePrice, lateFee, damageFee);
    }
}

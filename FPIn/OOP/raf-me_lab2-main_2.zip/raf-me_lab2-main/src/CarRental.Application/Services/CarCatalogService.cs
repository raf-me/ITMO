using CarRental.Application.Abstractions.Repositories;
using CarRental.Application.Abstractions.UseCases;
using CarRental.Application.Common;
using CarRental.Application.DTOs;
using CarRental.Application.Mappings;
using CarRental.Domain.Entities;
using CarRental.Domain.Enums;
using CarRental.Domain.Exceptions;

namespace CarRental.Application.Services;

public class CarCatalogService : ICarCatalogService
{
    private readonly ICarRepository _carRepo;

    private readonly IUnitOfWork _uow;

    public CarCatalogService(ICarRepository carRepo, IUnitOfWork uow)
    {
        _carRepo = carRepo;
        _uow = uow;
    }

    public async Task<PagedResult<CarDto>> GetCarsAsync(CarFilterDto filter, CancellationToken ct = default)
    {
        int page = Math.Max(1, filter.Page);
        int pageSize = Math.Clamp(filter.PageSize, 1, 100);
        var (items, totalCount) = await _carRepo.GetPagedAsync(
            filter.Status,
            filter.Category,
            filter.MinPricePerDay,
            filter.MaxPricePerDay,
            page,
            pageSize,
            ct);

        return new PagedResult<CarDto>(items.Select(c => c.ToDto()).ToList(), totalCount, page, pageSize);
    }

    public async Task<CarDto?> GetCarByIdAsync(Guid id, CancellationToken ct = default)
    {
        var car = await _carRepo.GetByIdAsync(id, ct);
        return car?.ToDto();
    }

    public async Task<CarDto> AddCarAsync(CreateCarDto dto, CancellationToken ct = default)
    {
        if (await _carRepo.ExistsByVinAsync(dto.Vin, ct))
            throw new DuplicateVinException(dto.Vin);

        var car = new Car(Guid.NewGuid(), dto.Vin, dto.Make, dto.Model, dto.Year, dto.Category, dto.PricePerDay, dto.Mileage);
        _carRepo.Add(car);
        await _uow.SaveChangesAsync(ct);
        return car.ToDto();
    }

    public async Task ChangeCarStatusAsync(Guid carId, CarStatus newStatus, CancellationToken ct = default)
    {
        var car = await _carRepo.GetByIdAsync(carId, ct)
            ?? throw new KeyNotFoundException("Автомобиль не найден.");

        if (newStatus == car.Status) return;
        switch (newStatus)
        {
            case CarStatus.Available when car.Status == CarStatus.Rented:
                car.Complete();
                break;
            case CarStatus.Available when car.Status == CarStatus.UnderMaintenance:
                car.ReturnFromMaintenance();
                break;
            case CarStatus.Rented:
                car.Rent();
                break;
            case CarStatus.UnderMaintenance:
                car.SendToMaintenance();
                break;
            default:
                throw new InvalidOperationException("Недопустимое изменение статуса автомобиля.");
        }

        _carRepo.Update(car);
        await _uow.SaveChangesAsync(ct);
    }
}

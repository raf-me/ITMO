using CarRental.Domain.Enums;

namespace CarRental.Domain.Policies;

public sealed record DriverEligibilityRequirement(
    CarCategory Category,
    int MinimumAgeYears,
    int MinimumDrivingExperienceYears);

using CarRental.Domain.Enums;

namespace CarRental.Domain.Policies;

public interface IDriverEligibilityPolicy
{
    DriverEligibilityRequirement GetRequirementFor(CarCategory category);
}

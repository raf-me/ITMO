using CarRental.Domain.Enums;

namespace CarRental.Domain.Policies;

public sealed class DefaultDriverEligibilityPolicy : IDriverEligibilityPolicy
{
    private static readonly Dictionary<CarCategory, DriverEligibilityRequirement> Requirements = new()
    {
        [CarCategory.Economy] = new(CarCategory.Economy, 18, 1),
        [CarCategory.Standard] = new(CarCategory.Standard, 21, 2),
        [CarCategory.Premium] = new(CarCategory.Premium, 25, 3),
        [CarCategory.Sport] = new(CarCategory.Sport, 25, 5),
    };

    public DriverEligibilityRequirement GetRequirementFor(CarCategory category)
    {
        if (!Requirements.TryGetValue(category, out DriverEligibilityRequirement? requirement))
            throw new ArgumentOutOfRangeException(nameof(category), category, "Неизвестная категория автомобиля.");

        return requirement;
    }
}

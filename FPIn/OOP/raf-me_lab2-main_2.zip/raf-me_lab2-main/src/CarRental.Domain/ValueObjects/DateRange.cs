namespace CarRental.Domain.ValueObjects;

public sealed class DateRange : IEquatable<DateRange>
{
    public DateOnly StartDate { get; }

    public DateOnly EndDate { get; }

    public int DurationInDays => EndDate.DayNumber - StartDate.DayNumber;

    private DateRange(DateOnly startDate, DateOnly endDate)
    {
        StartDate = startDate;
        EndDate = endDate;
    }

    public static DateRange Create(DateOnly startDate, DateOnly endDate)
    {
        if (endDate <= startDate)
            throw new ArgumentException("Дата окончания должна быть позже даты начала.", nameof(endDate));

        return new DateRange(startDate, endDate);
    }

    public bool Overlaps(DateRange other)
    {
        ArgumentNullException.ThrowIfNull(other);
        return StartDate < other.EndDate && other.StartDate < EndDate;
    }

    public bool Equals(DateRange? other) =>
        other is not null && StartDate == other.StartDate && EndDate == other.EndDate;

    public override bool Equals(object? obj) => Equals(obj as DateRange);

    public override int GetHashCode() => HashCode.Combine(StartDate, EndDate);
}

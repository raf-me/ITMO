using System.Text.RegularExpressions;

namespace CarRental.Domain.ValueObjects;

public sealed class Vin : IEquatable<Vin>
{
    private static readonly Regex VinRegex = new("^[A-HJ-NPR-Z0-9]{17}$", RegexOptions.Compiled);

    public string Value { get; }

    private Vin(string value)
    {
        Value = value;
    }

    public static Vin Create(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw new ArgumentException("VIN не может быть пустым.", nameof(value));

        string normalized = value.Trim().ToUpperInvariant();
        if (!VinRegex.IsMatch(normalized))
            throw new ArgumentException("VIN должен состоять из 17 символов A-Z/0-9 без I, O, Q.", nameof(value));

        return new Vin(normalized);
    }

    public bool Equals(Vin? other) => other is not null && Value == other.Value;

    public override bool Equals(object? obj) => Equals(obj as Vin);

    public override int GetHashCode() => Value.GetHashCode(StringComparison.Ordinal);

    public override string ToString() => Value;
}

using CarRental.Domain.Entities;
using CarRental.Domain.ValueObjects;

namespace CarRental.Domain.Services;

public interface IRentalPriceCalculator
{
    decimal CalculateBasePrice(Car car, DateRange period);

    decimal CalculateLateFee(Car car, DateOnly plannedReturnDate, DateOnly actualReturnDate);

    decimal CalculateTotal(decimal basePrice, decimal lateFee, decimal damageFee);
}

using CarRental.Domain.Entities;
using CarRental.Domain.ValueObjects;

namespace CarRental.Domain.Services;

public sealed class RentalPriceCalculator : IRentalPriceCalculator
{
    private const decimal LateFeeMultiplier = 1.5m;

    public decimal CalculateBasePrice(Car car, DateRange period)
    {
        ArgumentNullException.ThrowIfNull(car);
        ArgumentNullException.ThrowIfNull(period);

        return car.DailyRate * period.DurationInDays;
    }

    public decimal CalculateLateFee(Car car, DateOnly plannedReturnDate, DateOnly actualReturnDate)
    {
        ArgumentNullException.ThrowIfNull(car);

        int lateDays = actualReturnDate.DayNumber - plannedReturnDate.DayNumber;
        return lateDays <= 0 ? 0 : car.DailyRate * LateFeeMultiplier * lateDays;
    }

    public decimal CalculateTotal(decimal basePrice, decimal lateFee, decimal damageFee)
    {
        ArgumentOutOfRangeException.ThrowIfNegative(basePrice);
        ArgumentOutOfRangeException.ThrowIfNegative(lateFee);
        ArgumentOutOfRangeException.ThrowIfNegative(damageFee);

        return basePrice + lateFee + damageFee;
    }
}

using CarRental.Domain.Entities;
using CarRental.Domain.Enums;

namespace CarRental.Domain.Factories;

public sealed class RentalContractFactory : IRentalContractFactory
{
    public RentalContract CreateFor(RentalRequest approvedRequest, decimal basePrice)
    {
        ArgumentNullException.ThrowIfNull(approvedRequest);

        if (approvedRequest.Status != RentalRequestStatus.Approved)
            throw new InvalidOperationException("Договор можно создать только для одобренной заявки.");

        return new RentalContract(Guid.NewGuid(), approvedRequest.Id, basePrice);
    }
}

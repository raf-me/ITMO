using CarRental.Domain.Entities;

namespace CarRental.Domain.Factories;

public interface IUserFactory
{
    User Create(
        string username,
        string passwordHash,
        string firstName,
        string lastName,
        DateOnly dateOfBirth,
        DateOnly licenseDate,
        string email);
}

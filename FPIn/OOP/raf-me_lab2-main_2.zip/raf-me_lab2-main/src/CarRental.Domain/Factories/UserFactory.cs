using CarRental.Domain.Entities;

namespace CarRental.Domain.Factories;

public sealed class UserFactory : IUserFactory
{
    public User Create(
        string username,
        string passwordHash,
        string firstName,
        string lastName,
        DateOnly dateOfBirth,
        DateOnly licenseDate,
        string email)
    {
        return new User(
            Guid.NewGuid(),
            username,
            passwordHash,
            firstName,
            lastName,
            dateOfBirth,
            licenseDate,
            email);
    }
}

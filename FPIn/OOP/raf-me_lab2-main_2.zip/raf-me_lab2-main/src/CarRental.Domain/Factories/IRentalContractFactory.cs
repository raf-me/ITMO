using CarRental.Domain.Entities;

namespace CarRental.Domain.Factories;

public interface IRentalContractFactory
{
    RentalContract CreateFor(RentalRequest approvedRequest, decimal basePrice);
}

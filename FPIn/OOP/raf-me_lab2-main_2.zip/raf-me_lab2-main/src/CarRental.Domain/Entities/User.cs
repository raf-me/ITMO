namespace CarRental.Domain.Entities;

public class User
{
    public Guid Id { get; private set; }

    public string Username { get; private set; } = string.Empty;

    public string PasswordHash { get; private set; } = string.Empty;

    public string FirstName { get; private set; } = string.Empty;

    public string LastName { get; private set; } = string.Empty;

    public DateOnly DateOfBirth { get; private set; }

    public DateOnly LicenseDate { get; private set; }

    public string Email { get; private set; } = string.Empty;

    public IReadOnlyCollection<Role> Roles => _roles.AsReadOnly();

    public IReadOnlyCollection<RentalRequest> RentalRequests => _rentalRequests.AsReadOnly();

    public int AgeInYears => CalculateFullYears(DateOfBirth, DateOnly.FromDateTime(DateTime.Today));

    public int DrivingExperienceYears => CalculateFullYears(LicenseDate, DateOnly.FromDateTime(DateTime.Today));

    public User(
        Guid id,
        string username,
        string passwordHash,
        string firstName,
        string lastName,
        DateOnly dateOfBirth,
        DateOnly licenseDate,
        string email)
    {
        if (id == Guid.Empty) throw new ArgumentException("Id не может быть пустым.", nameof(id));
        if (string.IsNullOrWhiteSpace(username)) throw new ArgumentException("Логин обязателен.", nameof(username));
        if (string.IsNullOrWhiteSpace(passwordHash)) throw new ArgumentException("Хэш пароля обязателен.", nameof(passwordHash));
        if (string.IsNullOrWhiteSpace(firstName)) throw new ArgumentException("Имя обязательно.", nameof(firstName));
        if (string.IsNullOrWhiteSpace(lastName)) throw new ArgumentException("Фамилия обязательна.", nameof(lastName));
        if (string.IsNullOrWhiteSpace(email)) throw new ArgumentException("Email обязателен.", nameof(email));
        if (licenseDate < dateOfBirth) throw new ArgumentException("Дата получения прав не может быть раньше даты рождения.", nameof(licenseDate));

        Id = id;
        Username = username.Trim();
        PasswordHash = passwordHash;
        FirstName = firstName.Trim();
        LastName = lastName.Trim();
        DateOfBirth = dateOfBirth;
        LicenseDate = licenseDate;
        Email = email.Trim();
    }

    public void AddRole(Role role)
    {
        ArgumentNullException.ThrowIfNull(role);
        if (_roles.Exists(r => r.Name == role.Name))
            throw new InvalidOperationException("Роль уже назначена пользователю.");

        _roles.Add(role);
    }

    private readonly List<Role> _roles = new();

    private readonly List<RentalRequest> _rentalRequests = new();

    private User()
    {
    }

    private static int CalculateFullYears(DateOnly from, DateOnly to)
    {
        int years = to.Year - from.Year;
        if (to < from.AddYears(years)) years--;
        return Math.Max(0, years);
    }
}

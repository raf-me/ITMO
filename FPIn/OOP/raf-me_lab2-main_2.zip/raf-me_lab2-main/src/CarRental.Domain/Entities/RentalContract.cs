namespace CarRental.Domain.Entities;

public class RentalContract
{
    public Guid Id { get; private set; }

    public Guid RentalRequestId { get; private set; }

    public RentalRequest RentalRequest
    {
        get => _rentalRequest ?? throw new InvalidOperationException("Заявка договора не инициализирована.");
        private set => _rentalRequest = value;
    }

    public decimal BasePrice { get; private set; }

    public DateOnly? ActualReturnDate { get; private set; }

    public decimal LateFee { get; private set; }

    public decimal DamageFee { get; private set; }

    public decimal TotalPrice { get; private set; }

    public DateTime CreatedAt { get; private set; }

    public RentalContract(Guid id, Guid rentalRequestId, decimal basePrice)
    {
        if (id == Guid.Empty) throw new ArgumentException("Id не может быть пустым.", nameof(id));
        if (rentalRequestId == Guid.Empty) throw new ArgumentException("RentalRequestId не может быть пустым.", nameof(rentalRequestId));
        ArgumentOutOfRangeException.ThrowIfNegative(basePrice);

        Id = id;
        RentalRequestId = rentalRequestId;
        BasePrice = basePrice;
        LateFee = 0;
        DamageFee = 0;
        TotalPrice = basePrice;
        CreatedAt = DateTime.UtcNow;
    }

    public void Complete(DateOnly actualReturnDate, decimal lateFee, decimal damageFee)
    {
        ArgumentOutOfRangeException.ThrowIfNegative(lateFee);
        ArgumentOutOfRangeException.ThrowIfNegative(damageFee);

        ActualReturnDate = actualReturnDate;
        LateFee = lateFee;
        DamageFee = damageFee;
        TotalPrice = BasePrice + LateFee + DamageFee;
    }

    private RentalRequest? _rentalRequest;

    private RentalContract()
    {
    }
}

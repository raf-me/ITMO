using CarRental.Domain.Enums;

namespace CarRental.Domain.Entities;

public class Role
{
    public Guid Id { get; private set; }

    public UserRole Name { get; private set; }

    public IReadOnlyCollection<User> Users => _users.AsReadOnly();

    public Role(Guid id, UserRole name)
    {
        if (id == Guid.Empty) throw new ArgumentException("Id не может быть пустым.", nameof(id));

        Id = id;
        Name = name;
    }

    private readonly List<User> _users = new();

    private Role()
    {
    }
}

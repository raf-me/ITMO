using CarRental.Domain.Enums;
using CarRental.Domain.ValueObjects;

namespace CarRental.Domain.Entities;

public class RentalRequest
{
    public Guid Id { get; private set; }

    public Guid UserId { get; private set; }

    public User User
    {
        get => _user ?? throw new InvalidOperationException("Пользователь заявки не инициализирован.");
        private set => _user = value;
    }

    public Guid CarId { get; private set; }

    public Car Car
    {
        get => _car ?? throw new InvalidOperationException("Автомобиль заявки не инициализирован.");
        private set => _car = value;
    }

    public DateOnly StartDate { get; private set; }

    public DateOnly EndDate { get; private set; }

    public RentalRequestStatus Status { get; private set; }

    public string? ManagerComment { get; private set; }

    public DateTime CreatedAt { get; private set; }

    public RentalContract? Contract { get; private set; }

    public RentalRequest(Guid id, Guid userId, Guid carId, DateOnly startDate, DateOnly endDate)
    {
        if (id == Guid.Empty) throw new ArgumentException("Id не может быть пустым.", nameof(id));
        if (userId == Guid.Empty) throw new ArgumentException("UserId не может быть пустым.", nameof(userId));
        if (carId == Guid.Empty) throw new ArgumentException("CarId не может быть пустым.", nameof(carId));
        if (startDate < DateOnly.FromDateTime(DateTime.Today))
            throw new ArgumentException("Дата начала аренды не может быть в прошлом.", nameof(startDate));

        DateRange.Create(startDate, endDate);

        Id = id;
        UserId = userId;
        CarId = carId;
        StartDate = startDate;
        EndDate = endDate;
        Status = RentalRequestStatus.Pending;
        CreatedAt = DateTime.UtcNow;
    }

    public void Approve()
    {
        if (Status != RentalRequestStatus.Pending)
            throw new InvalidOperationException("Одобрить можно только ожидающую заявку.");

        Status = RentalRequestStatus.Approved;
    }

    public void Reject(string comment)
    {
        if (Status != RentalRequestStatus.Pending)
            throw new InvalidOperationException("Отклонить можно только ожидающую заявку.");
        if (string.IsNullOrWhiteSpace(comment))
            throw new ArgumentException("Причина отклонения обязательна.", nameof(comment));

        Status = RentalRequestStatus.Rejected;
        ManagerComment = comment.Trim();
    }

    public void Complete()
    {
        if (Status != RentalRequestStatus.Approved)
            throw new InvalidOperationException("Завершить можно только одобренную заявку.");

        Status = RentalRequestStatus.Completed;
    }

    private User? _user;

    private Car? _car;

    private RentalRequest()
    {
    }
}

using CarRental.Domain.Enums;
using CarRental.Domain.ValueObjects;

namespace CarRental.Domain.Entities;

public class Car
{
    public Guid Id { get; private set; }

    public Vin Vin
    {
        get => _vin ?? throw new InvalidOperationException("VIN не инициализирован.");
        private set => _vin = value;
    }

    public string Make { get; private set; } = string.Empty;

    public string Model { get; private set; } = string.Empty;

    public int Year { get; private set; }

    public CarCategory Category { get; private set; }

    public CarStatus Status { get; private set; }

    public decimal DailyRate { get; private set; }

    public int Mileage { get; private set; }

    public IReadOnlyCollection<RentalRequest> RentalRequests => _rentalRequests.AsReadOnly();

    public Car(
        Guid id,
        string vin,
        string make,
        string model,
        int year,
        CarCategory category,
        decimal dailyRate,
        int mileage)
    {
        if (id == Guid.Empty) throw new ArgumentException("Id не может быть пустым.", nameof(id));
        if (string.IsNullOrWhiteSpace(make)) throw new ArgumentException("Марка обязательна.", nameof(make));
        if (string.IsNullOrWhiteSpace(model)) throw new ArgumentException("Модель обязательна.", nameof(model));
        if (year < 1900 || year > 2100) throw new ArgumentOutOfRangeException(nameof(year));
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(dailyRate);
        ArgumentOutOfRangeException.ThrowIfNegative(mileage);

        Id = id;
        Vin = Vin.Create(vin);
        Make = make.Trim();
        Model = model.Trim();
        Year = year;
        Category = category;
        DailyRate = dailyRate;
        Mileage = mileage;
        Status = CarStatus.Available;
    }

    public void Rent()
    {
        if (Status != CarStatus.Available)
            throw new InvalidOperationException("Арендовать можно только доступный автомобиль.");

        Status = CarStatus.Rented;
    }

    public void Complete()
    {
        if (Status != CarStatus.Rented)
            throw new InvalidOperationException("Завершить аренду можно только для арендованного автомобиля.");

        Status = CarStatus.Available;
    }

    public void SendToMaintenance()
    {
        if (Status != CarStatus.Available)
            throw new InvalidOperationException("На обслуживание можно отправить только доступный автомобиль.");

        Status = CarStatus.UnderMaintenance;
    }

    public void ReturnFromMaintenance()
    {
        if (Status != CarStatus.UnderMaintenance)
            throw new InvalidOperationException("Вернуть можно только автомобиль на обслуживании.");

        Status = CarStatus.Available;
    }

    private readonly List<RentalRequest> _rentalRequests = new();

    private Vin? _vin;

    private Car()
    {
    }
}

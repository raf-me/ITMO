# SOLID и паттерны в лабораторной работе

## Clean Architecture

Проект разделён на четыре слоя:

- `CarRental.Domain` — бизнес-модель: сущности, value objects, доменные политики, доменные сервисы, фабрики и исключения.
- `CarRental.Application` — сценарии использования системы: сервисы приложения, DTO, маппинг, абстракции репозиториев и внешних сервисов.
- `CarRental.Infrastructure` — техническая реализация: EF Core, PostgreSQL, репозитории, BCrypt, JWT.
- `CarRental.Api` — входная точка: контроллеры, авторизация, middleware обработки ошибок.

Зависимости направлены внутрь: API и Infrastructure зависят от Application/Domain, а Domain не зависит ни от базы данных, ни от ASP.NET Core.

## SOLID

### S — Single Responsibility Principle

Каждый класс отвечает за одну задачу:

- `Car`, `User`, `RentalRequest`, `RentalContract` хранят состояние и защищают инварианты домена.
- `RentalEligibilityService` проверяет право клиента на аренду.
- `RentalPricingService` отдаёт расчёты стоимости через доменный калькулятор.
- `AuthService` отвечает за регистрацию и вход.
- `CarCatalogService` отвечает за каталог автомобилей.
- `UserManagementService` отвечает за администрирование пользователей.
- `ExceptionHandlingMiddleware` централизованно превращает исключения в HTTP-ответы.

### O — Open/Closed Principle

Бизнес-правила вынесены в расширяемые политики и сервисы:

- `IDriverEligibilityPolicy` позволяет заменить требования к возрасту и стажу без переписывания `RentalEligibilityService`.
- `IRentalPriceCalculator` позволяет заменить алгоритм расчёта стоимости без изменения API и сервисов приложения.
- `CarFilterSpecification` инкапсулирует фильтрацию автомобилей и может расширяться новыми критериями.

### L — Liskov Substitution Principle

Сервисы работают через интерфейсы:

- `ICarRepository`, `IUserRepository`, `IRentalRequestRepository`, `IRentalContractRepository`.
- `IPasswordHasher`, `IJwtTokenGenerator`, `IDateTimeProvider`.
- `IRentalPricingService`, `IRentalEligibilityService`.

Любую реализацию этих интерфейсов можно заменить тестовой или другой инфраструктурной реализацией без изменения вызывающего кода.

### I — Interface Segregation Principle

Интерфейсы разделены по сценариям:

- Репозиторий автомобилей не содержит методов пользователей.
- Репозиторий пользователей не содержит методов заявок.
- `IRentalPricingService` содержит только расчёт стоимости.
- `IRentalEligibilityService` содержит только проверку допуска.

Классы зависят только от тех методов, которые реально используют.

### D — Dependency Inversion Principle

Application-слой не зависит от EF Core, BCrypt или JWT напрямую. Он зависит от абстракций:

- `IUnitOfWork` вместо прямого вызова `DbContext.SaveChangesAsync`.
- `IPasswordHasher` вместо прямого вызова BCrypt.
- `IJwtTokenGenerator` вместо прямой генерации JWT внутри `AuthService`.
- репозитории вместо прямого доступа к таблицам.

## Использованные паттерны

### Repository

Классы `CarRepository`, `UserRepository`, `RentalRequestRepository`, `RentalContractRepository`, `RoleRepository` скрывают EF Core от Application-слоя.

### Unit of Work

`UnitOfWork` объединяет изменения нескольких репозиториев в одну транзакционную операцию сохранения через `SaveChangesAsync`.

### Value Object

`Vin` и `DateRange` не имеют собственной идентичности и валидируют данные при создании. Это защищает домен от некорректных значений.

### Factory

`UserFactory` и `RentalContractFactory` централизуют создание сложных доменных объектов. Это убирает дублирование `Guid.NewGuid()` и правил создания из сервисов приложения.

### Policy / Strategy

`IDriverEligibilityPolicy` и `DefaultDriverEligibilityPolicy` описывают правила допуска к категориям автомобилей. При изменении требований достаточно заменить политику.

### Domain Service

`RentalPriceCalculator` реализует доменное правило расчёта стоимости аренды, которое не принадлежит одной сущности полностью.

### Specification

`CarFilterSpecification` инкапсулирует условия фильтрации каталога автомобилей, чтобы репозиторий не превращался в набор разрозненных `if`.

### DTO + Mapper

DTO отделяют внешний API-контракт от доменных сущностей. `EntityMappingExtensions` отвечает за преобразование сущностей в DTO.

### Middleware

`ExceptionHandlingMiddleware` централизует обработку ошибок и не размазывает `try/catch` по контроллерам.

### Dependency Injection

Все сервисы регистрируются в DI-контейнере, поэтому зависимости явно объявлены через конструкторы, а не создаются вручную внутри классов.
